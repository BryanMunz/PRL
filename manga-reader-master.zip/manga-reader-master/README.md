## What is this?
This is a template for manga website, show and publish manga everyday.

## Project Detail
* html 5
* css 3
* JQuery
* pdfjs
* Bootstrap 4

## ScreenShot
![index](https://user-images.githubusercontent.com/26200198/70475314-f4c68680-1adc-11ea-9954-ef5c3660229f.png)
![watch](https://user-images.githubusercontent.com/26200198/70475325-f8f2a400-1adc-11ea-968a-8e6c5d09836d.png)
